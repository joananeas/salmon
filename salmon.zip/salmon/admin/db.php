<?php
    $server = 'localhost';

    $username = 'db-username';

    $passwd = 'str0ng-passwd';

    $db = 'db-name';
?>
