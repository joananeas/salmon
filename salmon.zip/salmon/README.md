# gphishing - Current: v0.1
Welcome to Gphishing!
This is an email and password grabber, which emulates the login page of Google.<br>
It's developed by Joan Aneas (me), who started as a school project and now improved it to<br>
upload it to the web!<br>
If you want to participate in this project (the idea is to, in the future, have more than only one "emulation)<br>
send me a dm at instagram: @joananeas_ :)

# Configuration
If it's the first time installation, it will prompt a configuration Wizard to establish
all the Database parameters, which you can configure later. To view the emails and passwords,
and to re-configure the DB, you can go to the admin dashboard, at /admin.

# Status
Not finished yet!
